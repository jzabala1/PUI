function addNewList() {
    alert('hello world!');
}

function addListItem() {
    console.log("hello world!")
}


